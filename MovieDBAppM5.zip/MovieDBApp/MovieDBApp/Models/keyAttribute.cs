﻿using System;

namespace MovieDBApp.Models
{
    internal class keyAttribute : Attribute
    {
    }
}