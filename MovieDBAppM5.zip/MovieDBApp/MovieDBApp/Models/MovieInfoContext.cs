﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieDBApp.Models
{
    public class MovieInfoContext : DbContext
    {
        //Constructor
        public MovieInfoContext (DbContextOptions<MovieInfoContext> options) : base (options)
        {
            //Leave Blank for Now
        }
        public DbSet<MovieFormResponse> MovieInformation { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder mV)
        {
            mV.Entity<Category>().HasData(
                new Category { CategoryId = 1, CategoryName = "Action/Adventure" },
                new Category { CategoryId = 2, CategoryName = "Comedy" },
                new Category { CategoryId = 3, CategoryName = "Drama" },
                new Category { CategoryId = 4, CategoryName = "Family" },
                new Category { CategoryId = 5, CategoryName = "Horror/Suspense" },
                new Category { CategoryId = 6, CategoryName = "Miscellaneous" },
                new Category { CategoryId = 7, CategoryName = "Television" },
                new Category { CategoryId = 8, CategoryName = "VHS" }
            );

            mV.Entity<MovieFormResponse>().HasData(

                new MovieFormResponse
                {
                    MovieId = 1,
                    MovieTitle = "The Lake House",
                    CategoryId = 3,
                    MovieYear = 2006,
                    MovieDirector = "Alejandro Agresti",
                    MovieRating = "PG",
                    Edited = false,
                    LentTo = "",
                    Notes = ""
                },
                new MovieFormResponse
                {
                    MovieId = 2,
                    MovieTitle = "The Iron Giant",
                    CategoryId = 4,
                    MovieYear = 1999,
                    MovieDirector = "Brad Bird",
                    MovieRating = "PG",
                    Edited = false,
                    LentTo = "",
                    Notes = ""
                },
                new MovieFormResponse
                {
                    MovieId = 3,
                    MovieTitle = "Rocky",
                    CategoryId = 1,
                    MovieYear = 1976,
                    MovieDirector = "John G. Avildsen",
                    MovieRating = "PG",
                    Edited = false,
                    LentTo = "",
                    Notes = ""
                }
            );
        }
    }
}
