﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Threading.Tasks;

namespace MovieDBApp.Models
{
    public class MovieFormResponse
    {
        [Key]
        [Required]
        public int MovieId { get; set; }
        [Required (ErrorMessage = "*Required: Enter a movie title*")]
        public string MovieTitle { get; set; }
        
        [Required(ErrorMessage = "*Required: Enter a movie year*")]
        public int MovieYear { get; set; }
        [Required(ErrorMessage = "*Required: Enter a movie director*")]
        public string MovieDirector { get; set; }
        [Required(ErrorMessage = "*Required: Enter a movie rating*")]
        public string MovieRating { get; set; }
        public bool Edited { get; set; }
        public string LentTo { get; set; }
        public string Notes { get; set; }

        [Required(ErrorMessage = "*Required: select a movie category*")]
        public int CategoryId { get; set; }
        public Category Category { get; set; }
    }
}
