﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using MovieDBApp.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace MovieDBApp.Controllers
{
    public class HomeController : Controller
    {
        private MovieInfoContext _movieContext { get; set; }
        //constructor
        public HomeController(MovieInfoContext someName)
        {
            _movieContext = someName;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult MForm()
        {
            ViewBag.Categories = _movieContext.Categories.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult MForm(MovieFormResponse MovieRes)
        {
            if (ModelState.IsValid)
            {
                _movieContext.Add(MovieRes);
                _movieContext.SaveChanges();
                return View("Comfirmation", MovieRes);
            }
            else // if invalid
            {
                ViewBag.Categories = _movieContext.Categories.ToList();
                return View("MForm");
            }
        }

        public IActionResult MovieList ()
        {
            var applications = _movieContext.MovieInformation.
                Include(x => x.Category)
                .OrderBy(x => x.MovieTitle)
                .ToList();
            return View(applications);
        }

        [HttpGet]
        public IActionResult Edit (int movieid)
        {
            ViewBag.Categories = _movieContext.Categories.ToList();
            var application = _movieContext.MovieInformation.Single(x => x.MovieId == movieid);
            return View("MForm", application);
        }

        [HttpPost]
        public IActionResult Edit (MovieFormResponse MovieEd)
        {
            _movieContext.Update(MovieEd);
            _movieContext.SaveChanges();
            return RedirectToAction("MovieList"); //the name of the IActionResult view you want to go to goes here.
        }

        [HttpGet]
        public IActionResult Delete (int movieid)
        {
            var application = _movieContext.MovieInformation.Single(x => x.MovieId == movieid);

            return View(application);
        }

        [HttpPost]
        public IActionResult Delete (MovieFormResponse mv)
        {
            _movieContext.MovieInformation.Remove(mv);
            _movieContext.SaveChanges();

            return RedirectToAction("MovieList");
        }

    }
}
